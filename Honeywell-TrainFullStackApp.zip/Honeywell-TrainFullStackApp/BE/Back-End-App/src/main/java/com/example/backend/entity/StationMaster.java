package com.example.backend.entity;

import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class StationMaster {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;
		private String trainName;
		private int platformNo;
		private LocalTime arriavalTime;
		
		public StationMaster() {
			super();
		}

		public StationMaster(long id, String trainName, int platformNo, LocalTime arriavalTime) {
			super();
			this.id = id;
			this.trainName = trainName;
			this.platformNo = platformNo;
			this.arriavalTime = arriavalTime;
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getTrainName() {
			return trainName;
		}

		public void setTrainName(String trainName) {
			this.trainName = trainName;
		}

		public int getPlatformNo() {
			return platformNo;
		}

		public void setPlatformNo(int platformNo) {
			this.platformNo = platformNo;
		}

		public LocalTime getArriavalTime() {
			return arriavalTime;
		}

		public void setArriavalTime(LocalTime arriavalTime) {
			this.arriavalTime = arriavalTime;
		}
		
		
		
		
}
