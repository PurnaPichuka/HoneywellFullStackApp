package com.example.backend.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.entity.StationMaster;

public interface StationMasterRepositoty extends JpaRepository<StationMaster, Long>{

}
