package com.example.backend.service;

import java.util.List;

import com.example.backend.entity.StationMaster;

public interface StationMasterService {

	StationMaster addTrainDetails(StationMaster stationMaster);

	List<StationMaster> getTrainDetails();

	void deleteTrain(long id);

}
