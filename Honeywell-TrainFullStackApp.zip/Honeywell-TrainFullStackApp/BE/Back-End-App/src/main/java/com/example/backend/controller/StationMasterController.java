package com.example.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.entity.StationMaster;
import com.example.backend.service.StationMasterService;


@CrossOrigin("*")
@RestController
@RequestMapping("/trainDetails")
public class StationMasterController {
	
	@Autowired
	private StationMasterService stationMasterService;
	
	//CREATE
	@PostMapping
	public ResponseEntity<StationMaster> addTrainDetails(@RequestBody StationMaster stationMaster){
		StationMaster adding = stationMasterService.addTrainDetails(stationMaster);
		return new ResponseEntity<StationMaster>(adding, HttpStatus.CREATED);
	}
	
	//READ
	@GetMapping
	public ResponseEntity<List<StationMaster>> getTrainDetails(){
		List<StationMaster> getAll = stationMasterService.getTrainDetails();
		return new ResponseEntity<List<StationMaster>>(getAll, HttpStatus.OK);
	}
	
	//DELETE
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteTrain(@PathVariable("id") long id){
		stationMasterService.deleteTrain(id);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

}
