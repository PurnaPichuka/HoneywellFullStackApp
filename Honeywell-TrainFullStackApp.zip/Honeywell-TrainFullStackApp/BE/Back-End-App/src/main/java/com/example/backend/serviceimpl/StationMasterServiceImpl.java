package com.example.backend.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.backend.entity.StationMaster;
import com.example.backend.repositoty.StationMasterRepositoty;
import com.example.backend.service.StationMasterService;

@Service
public class StationMasterServiceImpl implements StationMasterService{

	@Autowired
	private StationMasterRepositoty stationMasterRepo;
	@Override
	public StationMaster addTrainDetails(StationMaster stationMaster) {
		return stationMasterRepo.save(stationMaster);
	}
	@Override
	public List<StationMaster> getTrainDetails() {
		return stationMasterRepo.findAll();
	}
	@Override
	public void deleteTrain(long id) {
		stationMasterRepo.deleteById(id);
	}

}
