package com.example.backend.entity;

public class User {

}
