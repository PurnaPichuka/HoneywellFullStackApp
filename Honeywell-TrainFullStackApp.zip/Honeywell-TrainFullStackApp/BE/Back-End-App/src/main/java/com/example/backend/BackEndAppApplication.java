package com.example.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndAppApplication.class, args);
	}

}
