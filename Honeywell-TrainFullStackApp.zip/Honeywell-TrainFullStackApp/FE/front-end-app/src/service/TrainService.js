import axios from 'axios';

const BASE_URL = 'http://localhost:8080/trainDetails';


class TrainService{

  createTrainDetails(train){
    return axios.post(BASE_URL, train)
  }

  getTrainDetails(){
    return axios.get(BASE_URL)
  }

  deleteTrain(id){
    return axios.delete(BASE_URL+'/'+id)
  }
  
  
}

export default new TrainService();
