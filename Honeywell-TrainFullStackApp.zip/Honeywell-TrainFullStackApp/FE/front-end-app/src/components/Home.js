import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <nav>
        <h1>Train Management Application</h1>
        <Link to='/login' className='btn btn-primary m-2'>Login</Link>
      </nav>
    </div>
  )
}

export default Home