import React, {useState, useEffect} from 'react'
import TrainService from '../service/TrainService';
import { Link } from 'react-router-dom';

const ListOfTrainDetails = () => {

  const [train, setTrain] = useState([])

  useEffect(() => {
    getTrainDetails();
  }, [])


  const getTrainDetails = ()=>{
    TrainService.getTrainDetails().then((response)=>{
      setTrain(response.data);
    })
  }

  const deleteTrain = (id)=>{
    TrainService.deleteTrain(id).then(()=>{
      getTrainDetails();
  })
  }
  
  return (
    <div>
      <div>
        <Link to='/addTrain' className='btn btn-primary m-2'>Add Train Details</Link>
      </div>
       <table className='table table-striped table-bordered border-dark'>
                <thead>
                    <tr>
                        <th>Sr.No</th>
                        <th>Train Name</th>
                        <th>Platform No</th>
                        <th>Arriaval Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        train.map((item, index)=>
                            <tr key={item.id}>
                                <td>{index+1}</td>
                                <td>{item.trainName}</td>
                                <td>{item.platformNo}</td>
                                <td>{item.arriavalTime}</td>
                                <td>
                                  <button onClick={()=>deleteTrain(item.id)} className='btn btn-danger mx-1'>Delete</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
    </div>
  )
}

export default ListOfTrainDetails