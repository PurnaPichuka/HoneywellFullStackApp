import React, {useState} from 'react';
import { Link,useNavigate } from 'react-router-dom';

const Login = () => {

    const navigate = useNavigate();

    const adminEmail = 'master@gmail.com'
    const adminPassword = 'master@123'

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const sumbit = (e)=>{
        e.preventDefault();

        if (email === adminEmail && password === adminPassword) {
          navigate("/train");
          alert("Login Successfully");
        } else {
            alert("Bad Credentials");
        }
    }

  return (
    <div>
    <h1>Enter your credentials</h1>
    <form className='form'>
              <div>
                  <label className='form-label'>Email:</label>
                  <input 
                      type='email'
                      placeholder='enter ur email'
                      value={email}
                      onChange={(e)=>{setEmail(e.target.value)}}
                      className='form-group'
                  />
              </div>
              <div>
                  <label>Password: </label>
                  <input 
                      type='password'
                      placeholder='enter ur password'
                      value={password}
                      onChange={(e)=>{setPassword(e.target.value)}}
                  />
              </div>
              <div>
                  <button onClick={(e)=>sumbit(e)} className='btn btn-success m-2'>Submit</button>
                  <Link to='/' className='btn btn-danger m-2'>Cancel</Link>
              </div>
          </form>
  </div>
  )
}

export default Login