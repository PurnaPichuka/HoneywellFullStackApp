import React, {useState} from 'react';
import { Link, useNavigate } from 'react-router-dom';
import TrainService from '../service/TrainService';

const AddTrainDetails = () => {

    const [trainName, setTrainName] = useState('');
    const [platformNo, setPlatformNo] = useState('');
    const [arriavalTime, setArriavalTime] = useState('');
    const navigate = useNavigate();

    const save = (e)=>{

        e.preventDefault();

            const train = {trainName, platformNo, arriavalTime}

          TrainService.createTrainDetails(train).then((response)=>{
            // console.log(response)
              navigate('/train')
          }).catch(error => {
              console.log(error)
          })
    }


  return (
    <div>
        <form>
            <div>
                <h1>Adding Train Details</h1>
            </div>
                <div>
                    <label className='form-label'>Train Name</label>
                    <input 
                        type='text'
                        placeholder='enter train name'
                        value={trainName}
                        onChange={(e)=>{setTrainName(e.target.value)}}
                        className='form-group'
                    />
                </div>

                <div>
                    <label className='form-label'>Platform No</label>
                    <input 
                        type='text'
                        placeholder='enter platformNo'
                        value={platformNo}
                        onChange={(e)=>{setPlatformNo(e.target.value)}}
                        className='form-group'
                    />
                </div>

                <div>
                    <label className='form-label'>ArriavalTime Name</label>
                    <input 
                        type='time'
                        placeholder='enter arriavalTime'
                        value={arriavalTime}
                        onChange={(e)=>{setArriavalTime(e.target.value)}}
                        className='form-group'
                    />
                </div>

                <div>
                    <button onClick={(e)=>save(e)} className='btn btn-success m-2'>Submit</button>
                    <Link to='/train' className='btn btn-danger m-2'>Cancel</Link>
                </div>
        </form>
    </div>
  )
}

export default AddTrainDetails